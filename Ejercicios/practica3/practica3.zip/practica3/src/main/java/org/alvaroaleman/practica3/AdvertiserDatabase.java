package org.alvaroaleman.practica3;

/**
 * @author Antonio J. Nebro
 */
public interface AdvertiserDatabase {
  boolean findAdviser(String adviserName);
}

package org.alvaroaleman.practica3;

public class FullBoardException extends RuntimeException {
}
